AUTHOR = "EVAN"


def hello_world():
    print("Hello World")


def author():
    print("Author: ", AUTHOR)
