def print_dict(dict_t):
    for key, value in dict_t:
        print(key, value, "\n")