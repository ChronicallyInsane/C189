def print_set(set_t):
    for i in set_t:
        print(set_t[i], "\n")